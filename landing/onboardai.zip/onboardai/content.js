"use strict";
(() => {
  // src/content/trigger.ts
  var CURSOR_CLASS = "__onboardai-cmd";
  function installCursorStyle() {
    const url = chrome.runtime.getURL("cursor.png");
    const css = `html.${CURSOR_CLASS}, html.${CURSOR_CLASS} * { cursor: url("${url}") 16 16, help !important; }`;
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(css);
      document.adoptedStyleSheets = [...document.adoptedStyleSheets, sheet];
    } catch {
      const style = document.createElement("style");
      style.textContent = css;
      (document.head ?? document.documentElement).appendChild(style);
    }
  }
  function initTrigger(opts) {
    installCursorStyle();
    let held = false;
    const setHeld = (on) => {
      const next = on && opts.isEnabled();
      document.documentElement.classList.toggle(CURSOR_CLASS, next);
      if (next !== held) {
        held = next;
        opts.onModifier?.(held);
      }
    };
    const clearHeld = () => setHeld(false);
    const keyHandler = (e) => setHeld(e.metaKey || e.ctrlKey);
    const mouseHandler = (e) => {
      if (!opts.isEnabled()) return;
      if (!e.metaKey && !e.ctrlKey) return;
      const path = e.composedPath();
      if (opts.isOurNode(path)) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.type === "click" && e.button === 0) {
        const first = path[0];
        const target = first instanceof Element ? first : e.target instanceof Element ? e.target : document.documentElement;
        opts.onTrigger({ x: e.clientX, y: e.clientY, target });
      }
    };
    window.addEventListener("click", mouseHandler, { capture: true });
    window.addEventListener("mousedown", mouseHandler, { capture: true });
    window.addEventListener("auxclick", mouseHandler, { capture: true });
    window.addEventListener("keydown", keyHandler, { capture: true });
    window.addEventListener("keyup", keyHandler, { capture: true });
    window.addEventListener("blur", clearHeld);
    document.addEventListener("visibilitychange", clearHeld);
    return { reset: clearHeld };
  }

  // src/content/extract.ts
  function clean(s) {
    return (s ?? "").replace(/\s+/g, " ").trim();
  }
  function truncate(s, max) {
    return s.length > max ? s.slice(0, max - 1).trimEnd() + "\u2026" : s;
  }
  function scrubEmails(s) {
    return s.replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, "(email)");
  }
  function isEditable(el2) {
    if (el2 instanceof HTMLElement && el2.isContentEditable) return true;
    const v = el2.getAttribute("contenteditable");
    return v !== null && v.toLowerCase() !== "false";
  }
  function cleanedTitle() {
    const t = scrubEmails(clean(document.title));
    const first = t.split(/\s+[|\u2013\u2014\u00b7-]\s+/)[0];
    return first || t;
  }
  var INTERACTIVE = 'button, a, [role="button"], [role="tab"], [role="menuitem"], [role="link"], summary, label, input, select, textarea';
  function resolveTarget(target) {
    for (let el2 = target; el2 && el2 !== document.body; el2 = el2.parentElement) {
      if (isEditable(el2)) continue;
      const isFormControl = el2.tagName === "INPUT" || el2.tagName === "TEXTAREA" || el2.tagName === "SELECT";
      if (!isFormControl) {
        const aria = clean(el2.getAttribute("aria-label"));
        if (aria) return { el: el2, label: truncate(aria, 80) };
      }
      if (!el2.matches(INTERACTIVE)) continue;
      const img = el2.querySelector("img[alt]");
      const type = (el2.getAttribute("type") ?? "").toLowerCase();
      const isButtonInput = el2.tagName === "INPUT" && ["submit", "button", "reset"].includes(type);
      const t = (isFormControl && !isButtonInput ? "" : clean(el2.textContent)) || clean(el2.getAttribute("placeholder")) || clean(el2.getAttribute("title")) || clean(img?.getAttribute("alt")) || (isButtonInput ? clean(el2.value) : "");
      if (t) return { el: el2, label: truncate(t, 80) };
      if (isFormControl) {
        return { el: el2, label: type ? `${type} input field` : "input field" };
      }
    }
    const heading = nearestHeading(target);
    if (heading) return { el: target, label: truncate(heading, 80) };
    const title = cleanedTitle();
    return { el: target, label: title ? `${truncate(title, 60)} page` : "this page" };
  }
  function nearestHeading(target) {
    let el2 = target.closest(
      'section, article, form, fieldset, nav, aside, header, main, [role="region"], [role="dialog"]'
    );
    while (el2) {
      const h = el2.querySelector('h1, h2, h3, h4, legend, [role="heading"]');
      const t = clean(h?.textContent);
      if (t) return t;
      el2 = el2.parentElement?.closest(
        'section, article, form, fieldset, nav, aside, header, main, [role="region"], [role="dialog"]'
      ) ?? null;
    }
    return "";
  }
  var ATTR_WHITELIST = /^(id|class|href|src|role|type|name|title|alt|placeholder|for|action|method|datetime|colspan|rowspan|aria-.+|data-testid)$/;
  function sanitizedHtml(el2, budget) {
    const clone = el2.cloneNode(true);
    const all = [clone, ...Array.from(clone.querySelectorAll("*"))];
    for (const node of all) {
      if (/^(script|style|svg|iframe|video|audio|canvas|input|textarea|select)$/i.test(node.tagName) || isEditable(node)) {
        node.replaceChildren();
      }
      for (const attr of Array.from(node.attributes)) {
        if (!ATTR_WHITELIST.test(attr.name)) {
          node.removeAttribute(attr.name);
        } else if (attr.value.length > 120) {
          node.setAttribute(attr.name, attr.value.slice(0, 117) + "...");
        }
      }
    }
    return truncate(clone.outerHTML.replace(/\s+/g, " "), budget);
  }
  function textExcludingEditable(el2) {
    if (isEditable(el2)) return "";
    if (!el2.querySelector("[contenteditable]")) {
      return clean(el2.innerText ?? el2.textContent);
    }
    const clone = el2.cloneNode(true);
    for (const ed of Array.from(clone.querySelectorAll("[contenteditable]"))) {
      if ((ed.getAttribute("contenteditable") ?? "").toLowerCase() === "false") continue;
      ed.remove();
    }
    return clean(clone.textContent);
  }
  function surroundingText(target, budget) {
    let el2 = target;
    while (el2 && el2 !== document.body) {
      const t = textExcludingEditable(el2);
      if (t.length >= 80) return truncate(t, budget);
      el2 = el2.parentElement;
    }
    return document.body ? truncate(textExcludingEditable(document.body), budget) : "";
  }
  function navSummary(budget) {
    const links = document.querySelectorAll('nav a, [role="navigation"] a, header a');
    const seen = /* @__PURE__ */ new Set();
    for (const a of Array.from(links)) {
      const t = clean(a.textContent);
      if (t && t.length <= 40) seen.add(t);
      if (seen.size >= 25) break;
    }
    return truncate(Array.from(seen).join(" \xB7 "), budget);
  }
  function landmarkSummary(budget) {
    const parts = [];
    const present = ["main", "nav", "aside", "header", "footer", "form", "dialog[open]"].filter((sel) => document.querySelector(sel)).join(", ");
    if (present) parts.push(`landmarks: ${present}`);
    const headings = Array.from(document.querySelectorAll("h1, h2")).map((h) => clean(h.textContent)).filter((t) => t && t.length <= 80).slice(0, 8);
    if (headings.length > 0) parts.push(`top headings: ${headings.join(" | ")}`);
    return truncate(parts.join("; "), budget);
  }
  function extractContext(target, feature) {
    const parts = [];
    parts.push(`URL: ${location.origin + location.pathname}`);
    parts.push(`PAGE TITLE: ${scrubEmails(clean(document.title))}`);
    const desc = document.querySelector('meta[name="description"], meta[property="og:description"]')?.getAttribute("content");
    if (desc) parts.push(`META DESCRIPTION: ${truncate(clean(desc), 300)}`);
    parts.push(`CLICKED ELEMENT (label): ${feature}`);
    parts.push(`CLICKED ELEMENT (html): ${sanitizedHtml(target, 1e3)}`);
    const heading = nearestHeading(target);
    if (heading) parts.push(`NEAREST SECTION HEADING: ${truncate(heading, 120)}`);
    const around = surroundingText(target, 300);
    if (around) parts.push(`SURROUNDING TEXT: ${around}`);
    const nav = navSummary(400);
    if (nav) parts.push(`SITE NAVIGATION: ${nav}`);
    const landmarks = landmarkSummary(400);
    if (landmarks) parts.push(`PAGE STRUCTURE: ${landmarks}`);
    return parts.join("\n").slice(0, 6e3);
  }

  // src/content/styles.ts
  var POPUP_CSS = `
:host {
  all: initial;
}
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}
.box {
  position: fixed;
  z-index: 2147483647;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  width: 420px;
  max-width: 92vw;
  background: rgba(10, 22, 40, 0.97);
  color: #fffef5;
  border: 1px solid rgba(62, 184, 208, 0.35);
  border-radius: 16px;
  box-shadow: 0 12px 40px rgba(3, 8, 16, 0.55), 0 2px 8px rgba(3, 8, 16, 0.35), 0 0 0 1px rgba(62, 184, 208, 0.08);
  font-size: 13.5px;
  line-height: 1.45;
}
.header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border-bottom: 1px solid rgba(62, 184, 208, 0.18);
  background: #0d2035;
}
.badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex-shrink: 0;
  padding: 3px 9px;
  border-radius: 999px;
  background: #3eb8d0;
  color: #0a1628;
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 0.02em;
  white-space: nowrap;
}
.feature {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-weight: 600;
  font-size: 13px;
  color: #fffef5;
}
.icon-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  flex-shrink: 0;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: #a8d5df;
  font-size: 14px;
  cursor: pointer;
  padding: 0;
}
.icon-btn:hover { background: rgba(62, 184, 208, 0.18); color: #fffef5; }
.msgs {
  overflow-y: auto;
  max-height: 240px;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.box.expanded .msgs { max-height: 60vh; }
.msg-user {
  align-self: flex-end;
  max-width: 85%;
  padding: 6px 11px;
  border-radius: 14px 14px 4px 14px;
  background: #3eb8d0;
  color: #0a1628;
  font-weight: 500;
  white-space: pre-wrap;
  overflow-wrap: break-word;
}
.msg-ai {
  align-self: flex-start;
  max-width: 100%;
  padding: 7px 11px;
  border-radius: 14px 14px 14px 4px;
  background: rgba(255, 254, 245, 0.06);
  border: 1px solid rgba(62, 184, 208, 0.16);
  color: #fffef5;
  overflow-wrap: break-word;
}
.msg-ai p { margin: 0 0 6px; }
.msg-ai p:last-child { margin-bottom: 0; }
.msg-ai ul { margin: 0 0 6px; padding-left: 18px; }
.msg-ai ul:last-child { margin-bottom: 0; }
.msg-ai li { margin: 2px 0; }
.msg-ai strong { font-weight: 700; color: #ffffff; }
.msg-ai code {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  background: rgba(62, 184, 208, 0.16);
  color: #a8d5df;
  border-radius: 4px;
  padding: 0 4px;
}
.msg-error {
  align-self: flex-start;
  max-width: 100%;
  padding: 7px 11px;
  border-radius: 12px;
  background: rgba(220, 38, 38, 0.14);
  border: 1px solid rgba(248, 113, 113, 0.4);
  color: #fda4a4;
}
.msg-error button {
  display: block;
  margin-top: 6px;
  padding: 5px 12px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #e8b848, #d4a84a);
  color: #0a1628;
  font-size: 12px;
  font-weight: 700;
  cursor: pointer;
}
.msg-error button:hover { filter: brightness(1.08); }
.msg-consent {
  align-self: flex-start;
  max-width: 100%;
  padding: 8px 11px;
  border-radius: 12px;
  background: rgba(232, 184, 72, 0.1);
  border: 1px solid rgba(232, 184, 72, 0.45);
  color: #fffef5;
}
.msg-consent button {
  display: block;
  margin-top: 7px;
  padding: 5px 14px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #e8b848, #d4a84a);
  color: #0a1628;
  font-size: 12px;
  font-weight: 700;
  cursor: pointer;
}
.msg-consent button:hover { filter: brightness(1.08); }
.loader {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 2px;
}
.loader span {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #3eb8d0;
  animation: onboardai-bounce 1s infinite;
}
.loader span:nth-child(2) { animation-delay: 0.12s; }
.loader span:nth-child(3) { animation-delay: 0.24s; }
@keyframes onboardai-bounce {
  0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
  30% { transform: translateY(-4px); opacity: 1; }
}
.footer {
  border-top: 1px solid rgba(62, 184, 208, 0.18);
  padding: 8px 10px 7px;
  background: rgba(13, 32, 53, 0.6);
}
.input-row {
  display: flex;
  align-items: center;
  gap: 7px;
}
.input-row input {
  flex: 1;
  min-width: 0;
  height: 32px;
  padding: 0 11px;
  border: 1.5px solid rgba(168, 213, 223, 0.25);
  border-radius: 9px;
  background: rgba(255, 254, 245, 0.06);
  color: #fffef5;
  font-size: 13px;
  outline: none;
}
.input-row input:focus { border-color: #3eb8d0; background: rgba(255, 254, 245, 0.1); }
.input-row input::placeholder { color: rgba(168, 213, 223, 0.55); }
.send {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  flex-shrink: 0;
  border: none;
  border-radius: 50%;
  background: linear-gradient(135deg, #e8b848, #d4a84a);
  color: #0a1628;
  font-size: 14px;
  cursor: pointer;
  padding: 0;
}
.send:hover { filter: brightness(1.08); }
.send:disabled { opacity: 0.35; cursor: default; filter: none; }
.hint {
  margin: 6px 1px 0;
  font-size: 10.5px;
  color: rgba(168, 213, 223, 0.65);
}
.hint-lock {
  margin: 3px 1px 0;
  font-size: 10.5px;
  color: rgba(168, 213, 223, 0.85);
}
`;
  var SPOTLIGHT_CSS = `
:host {
  all: initial;
}
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}
.layer {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  pointer-events: none;
  overflow: hidden;
}
.cutout {
  position: fixed;
  pointer-events: none;
  border-radius: 6px;
  box-shadow:
    0 0 0 2px #3eb8d0,
    0 0 0 200vmax rgba(10, 22, 40, 0.5);
}
@media (prefers-reduced-motion: no-preference) {
  .cutout {
    transition: left 90ms ease-out, top 90ms ease-out, width 90ms ease-out,
      height 90ms ease-out, border-radius 90ms ease-out;
  }
}
.cutout.backdrop {
  box-shadow: 0 0 0 200vmax rgba(10, 22, 40, 0.5);
  transition: none;
}
.chip {
  position: fixed;
  pointer-events: none;
  max-width: 320px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  padding: 3px 10px;
  border-radius: 999px;
  background: #3eb8d0;
  color: #0a1628;
  font-size: 11.5px;
  font-weight: 700;
  letter-spacing: 0.01em;
  box-shadow: 0 2px 8px rgba(3, 8, 16, 0.4);
}
`;

  // src/content/popup.ts
  var MARGIN = 12;
  var OFFSET = 10;
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function renderInline(parent, text) {
    const re = /\*\*([^*]+)\*\*|`([^`]+)`/g;
    let last = 0;
    let m;
    while (m = re.exec(text)) {
      if (m.index > last) parent.appendChild(document.createTextNode(text.slice(last, m.index)));
      if (m[1] !== void 0) {
        parent.appendChild(el("strong", void 0, m[1]));
      } else {
        parent.appendChild(el("code", void 0, m[2]));
      }
      last = m.index + m[0].length;
    }
    if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)));
  }
  function renderMarkdown(container, text) {
    container.replaceChildren();
    let ul = null;
    for (const rawLine of text.split("\n")) {
      const line = rawLine.replace(/^#{1,4}\s+/, "");
      const bullet = /^\s*(?:[-*\u2022]|\d+[.)])\s+(.*)$/.exec(line);
      if (bullet) {
        if (!ul) {
          ul = el("ul");
          container.appendChild(ul);
        }
        const li = el("li");
        renderInline(li, bullet[1]);
        ul.appendChild(li);
        continue;
      }
      ul = null;
      if (!line.trim()) continue;
      const p = el("p");
      renderInline(p, line);
      container.appendChild(p);
    }
  }
  var Popup = class {
    host;
    box;
    msgs;
    inputEl;
    sendBtn;
    cb;
    x;
    y;
    ro = null;
    loader = null;
    assistantBubble = null;
    assistantRaw = "";
    expanded = false;
    onResize = () => this.place();
    constructor(x, y, feature, cb) {
      this.x = x;
      this.y = y;
      this.cb = cb;
      this.host = el("div");
      this.host.setAttribute("data-onboardai", "");
      const shadow = this.host.attachShadow({ mode: "open" });
      try {
        const sheet = new CSSStyleSheet();
        sheet.replaceSync(POPUP_CSS);
        shadow.adoptedStyleSheets = [sheet];
      } catch {
        const style = el("style");
        style.textContent = POPUP_CSS;
        shadow.appendChild(style);
      }
      this.box = el("div", "box");
      this.box.setAttribute("role", "dialog");
      this.box.setAttribute("aria-label", `OnboardAI \u2014 ${feature}`);
      this.box.style.left = "-9999px";
      this.box.style.top = "-9999px";
      this.box.style.visibility = "hidden";
      const header = el("div", "header");
      const badge = el("span", "badge", "\u2726 OnboardAI \xB7 by Shoofly");
      const featureEl = el("span", "feature", feature);
      featureEl.title = feature;
      const expandBtn = el("button", "icon-btn", "\u2922");
      expandBtn.title = "Expand";
      expandBtn.setAttribute("aria-label", "Expand");
      expandBtn.addEventListener("click", () => {
        this.expanded = !this.expanded;
        this.box.classList.toggle("expanded", this.expanded);
        expandBtn.textContent = this.expanded ? "\u2921" : "\u2922";
        expandBtn.title = this.expanded ? "Collapse" : "Expand";
      });
      const closeBtn = el("button", "icon-btn", "\u2715");
      closeBtn.title = "Close";
      closeBtn.setAttribute("aria-label", "Close OnboardAI");
      closeBtn.addEventListener("click", () => this.cb.onClose());
      header.append(badge, featureEl, expandBtn, closeBtn);
      this.msgs = el("div", "msgs");
      const footer = el("div", "footer");
      const inputRow = el("div", "input-row");
      this.inputEl = el("input");
      this.inputEl.type = "text";
      this.inputEl.placeholder = 'Ask a follow-up \u2014 try "what if\u2026"';
      this.inputEl.addEventListener("keydown", (e) => {
        e.stopPropagation();
        if (e.key === "Enter") {
          e.preventDefault();
          this.submit();
        } else if (e.key === "Escape") {
          this.cb.onClose();
        }
      });
      this.inputEl.addEventListener("input", () => this.syncSendState());
      this.sendBtn = el("button", "send", "\u27A4");
      this.sendBtn.setAttribute("aria-label", "Send");
      this.sendBtn.addEventListener("click", () => this.submit());
      inputRow.append(this.inputEl, this.sendBtn);
      const hint = el("p", "hint", "\u2318-click anywhere to ask about it \xB7 Esc to close");
      const lock = el("p", "hint-lock", "\u{1F512} Never reads what you type \u2014 form values stay on this page");
      footer.append(inputRow, hint, lock);
      this.box.append(header, this.msgs, footer);
      shadow.appendChild(this.box);
      document.documentElement.appendChild(this.host);
      this.place();
      this.ro = new ResizeObserver(() => this.place());
      this.ro.observe(this.box);
      window.addEventListener("resize", this.onResize);
      this.inputEl.focus();
      this.syncSendState();
    }
    /** Anchor at the click point; flip/clamp so the box stays fully on screen. */
    place() {
      const { width: w, height: h } = this.box.getBoundingClientRect();
      if (w === 0) return;
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      let left = this.x + OFFSET;
      let top = this.y + OFFSET;
      if (left + w > vw - MARGIN) left = this.x - w - OFFSET;
      left = Math.max(MARGIN, Math.min(left, vw - w - MARGIN));
      if (top + h > vh - MARGIN) top = this.y - h - OFFSET;
      top = Math.max(MARGIN, Math.min(top, vh - h - MARGIN));
      this.box.style.left = `${Math.round(left)}px`;
      this.box.style.top = `${Math.round(top)}px`;
      this.box.style.visibility = "visible";
    }
    submit() {
      const text = this.inputEl.value.trim();
      if (!text || this.isBusy()) return;
      this.inputEl.value = "";
      this.syncSendState();
      this.cb.onSend(text);
    }
    isBusy() {
      return this.box.hasAttribute("aria-busy");
    }
    syncSendState() {
      this.sendBtn.disabled = !this.inputEl.value.trim() || this.isBusy();
    }
    scrollToBottom() {
      this.msgs.scrollTop = this.msgs.scrollHeight;
    }
    containsPath(path) {
      return path.includes(this.host);
    }
    addUser(text) {
      this.msgs.appendChild(el("div", "msg-user", text));
      this.scrollToBottom();
    }
    /** New (empty) assistant bubble + 3-dot loader until the first delta. */
    startAssistant() {
      this.assistantRaw = "";
      this.assistantBubble = null;
      this.box.setAttribute("aria-busy", "true");
      this.loader = el("div", "loader");
      this.loader.append(el("span"), el("span"), el("span"));
      this.msgs.appendChild(this.loader);
      this.scrollToBottom();
      this.syncSendState();
    }
    appendDelta(text) {
      if (this.loader) {
        this.loader.remove();
        this.loader = null;
        this.syncSendState();
      }
      if (!this.assistantBubble) {
        this.assistantBubble = el("div", "msg-ai");
        this.msgs.appendChild(this.assistantBubble);
      }
      this.assistantRaw += text;
      renderMarkdown(this.assistantBubble, this.assistantRaw);
      this.scrollToBottom();
    }
    finishAssistant() {
      this.box.removeAttribute("aria-busy");
      if (this.loader) {
        this.loader.remove();
        this.loader = null;
      }
      this.assistantBubble = null;
      this.assistantRaw = "";
      this.syncSendState();
      this.inputEl.focus();
    }
    /**
     * One-time consent notice (Chrome Web Store User Data policy: prominent
     * disclosure BEFORE any page content is transmitted). Nothing is sent until
     * the user clicks "Got it" — the bubble then hands control back via onAccept.
     */
    showConsent(onAccept) {
      const bubble = el("div", "msg-consent");
      bubble.appendChild(
        document.createTextNode(
          "First time: OnboardAI sends the clicked element\u2019s text and nearby page text (never what you type \u2014 no form values, passwords, or URL tokens) to Anthropic to generate the answer, using your API key."
        )
      );
      const btn = el("button", void 0, "Got it \u2014 ask away");
      btn.addEventListener("click", () => {
        bubble.remove();
        onAccept();
      });
      bubble.appendChild(btn);
      this.msgs.appendChild(bubble);
      this.scrollToBottom();
      btn.focus();
    }
    /** Error bubble; `withSetup` adds an "Open settings" button (no_key/auth). */
    showError(message, withSetup) {
      const bubble = el("div", "msg-error");
      bubble.appendChild(document.createTextNode(message));
      if (withSetup) {
        const btn = el("button", void 0, "Open OnboardAI settings");
        btn.addEventListener("click", () => this.cb.onOpenOptions());
        bubble.appendChild(btn);
      }
      this.msgs.appendChild(bubble);
      this.scrollToBottom();
    }
    destroy() {
      this.ro?.disconnect();
      this.ro = null;
      window.removeEventListener("resize", this.onResize);
      this.host.remove();
    }
  };

  // src/shared/messages.ts
  var CHAT_PORT_NAME = "onboardai-chat";

  // src/content/chat.ts
  var ChatSession = class {
    context;
    history = [];
    port = null;
    active = false;
    constructor(context) {
      this.context = context;
    }
    get busy() {
      return this.active;
    }
    send(text, ev) {
      if (this.active) return;
      this.history.push({ role: "user", content: text });
      this.active = true;
      let assistant = "";
      let finished = false;
      const finish = (port2) => {
        finished = true;
        this.active = false;
        if (this.port === port2) this.port = null;
        try {
          port2.disconnect();
        } catch {
        }
      };
      let port;
      try {
        port = chrome.runtime.connect({ name: CHAT_PORT_NAME });
      } catch {
        this.active = false;
        ev.onError("network", "OnboardAI was updated \u2014 reload this page to keep using it.");
        return;
      }
      this.port = port;
      port.onMessage.addListener((msg) => {
        if (msg.type === "delta") {
          assistant += msg.text;
          ev.onDelta(msg.text);
        } else if (msg.type === "done") {
          this.history.push({ role: "assistant", content: assistant || "(no answer)" });
          finish(port);
          ev.onDone();
        } else {
          finish(port);
          ev.onError(msg.code, msg.message);
        }
      });
      port.onDisconnect.addListener(() => {
        if (!finished) {
          finished = true;
          this.active = false;
          if (this.port === port) this.port = null;
          ev.onError("network", "Lost connection to the extension mid-answer. Try again.");
        }
      });
      port.postMessage({
        type: "chat",
        messages: this.history.slice(-12),
        context: this.context
      });
    }
    /** Disconnecting the port makes the background abort the upstream request. */
    abort() {
      const port = this.port;
      this.port = null;
      this.active = false;
      try {
        port?.disconnect();
      } catch {
      }
    }
  };

  // src/content/spotlight.ts
  var CHIP_GAP = 6;
  var MARGIN2 = 4;
  var Spotlight = class {
    host = null;
    cutout = null;
    chip = null;
    visible = false;
    target = null;
    lastRect = "";
    raf = 0;
    onMouseMove = (e) => {
      const first = e.composedPath()[0];
      let el2 = first instanceof Element ? first : null;
      for (let probe = el2; probe; ) {
        const root = probe.getRootNode();
        if (!(root instanceof ShadowRoot)) break;
        const h = root.host;
        if (h.hasAttribute("data-onboardai") || h.hasAttribute("data-onboardai-spotlight")) {
          el2 = null;
          break;
        }
        probe = h;
      }
      this.setTarget(el2);
    };
    onReposition = () => this.schedule();
    show() {
      if (this.visible) return;
      this.visible = true;
      this.ensureDom();
      this.target = null;
      this.lastRect = "";
      this.applyBackdropOnly();
      this.host.style.display = "";
      window.addEventListener("mousemove", this.onMouseMove, { capture: true, passive: true });
      window.addEventListener("scroll", this.onReposition, { capture: true, passive: true });
      window.addEventListener("resize", this.onReposition, { passive: true });
    }
    hide() {
      if (!this.visible) return;
      this.visible = false;
      this.target = null;
      this.lastRect = "";
      if (this.raf) cancelAnimationFrame(this.raf);
      this.raf = 0;
      window.removeEventListener("mousemove", this.onMouseMove, { capture: true });
      window.removeEventListener("scroll", this.onReposition, { capture: true });
      window.removeEventListener("resize", this.onReposition);
      if (this.host) this.host.style.display = "none";
    }
    destroy() {
      this.hide();
      this.host?.remove();
      this.host = null;
      this.cutout = null;
      this.chip = null;
    }
    ensureDom() {
      if (this.host) return;
      this.host = document.createElement("div");
      this.host.setAttribute("data-onboardai-spotlight", "");
      const shadow = this.host.attachShadow({ mode: "open" });
      try {
        const sheet = new CSSStyleSheet();
        sheet.replaceSync(SPOTLIGHT_CSS);
        shadow.adoptedStyleSheets = [sheet];
      } catch {
        const style = document.createElement("style");
        style.textContent = SPOTLIGHT_CSS;
        shadow.appendChild(style);
      }
      const layer = document.createElement("div");
      layer.className = "layer";
      this.cutout = document.createElement("div");
      this.cutout.className = "cutout backdrop";
      this.chip = document.createElement("div");
      this.chip.className = "chip";
      this.chip.style.display = "none";
      layer.append(this.cutout, this.chip);
      shadow.appendChild(layer);
      document.documentElement.appendChild(this.host);
    }
    setTarget(el2) {
      if (el2 === this.target) return;
      this.target = el2;
      this.lastRect = "";
      this.schedule();
    }
    schedule() {
      if (this.raf || !this.visible) return;
      this.raf = requestAnimationFrame(() => {
        this.raf = 0;
        this.paint();
      });
    }
    applyBackdropOnly() {
      if (!this.cutout || !this.chip) return;
      this.cutout.classList.add("backdrop");
      this.cutout.style.left = "50vw";
      this.cutout.style.top = "50vh";
      this.cutout.style.width = "0px";
      this.cutout.style.height = "0px";
      this.cutout.style.borderRadius = "0px";
      this.chip.style.display = "none";
    }
    paint() {
      if (!this.visible || !this.cutout || !this.chip) return;
      const t = this.target;
      if (!t || !t.isConnected) {
        this.applyBackdropOnly();
        return;
      }
      const { el: el2, label } = resolveTarget(t);
      const rect = el2.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) {
        this.applyBackdropOnly();
        return;
      }
      const key = `${rect.left},${rect.top},${rect.width},${rect.height}|${label}`;
      if (key === this.lastRect) return;
      const radiusChanged = !this.lastRect || this.lastRect.split("|")[1] !== label;
      this.lastRect = key;
      this.cutout.classList.remove("backdrop");
      this.cutout.style.left = `${rect.left - 2}px`;
      this.cutout.style.top = `${rect.top - 2}px`;
      this.cutout.style.width = `${rect.width + 4}px`;
      this.cutout.style.height = `${rect.height + 4}px`;
      if (radiusChanged) {
        const br = getComputedStyle(el2).borderRadius;
        this.cutout.style.borderRadius = br && br !== "0px" ? br : "6px";
      }
      this.chip.style.display = "";
      this.chip.textContent = label;
      const cw = this.chip.offsetWidth;
      const ch = this.chip.offsetHeight;
      let cx = rect.left + rect.width / 2 - cw / 2;
      cx = Math.max(MARGIN2, Math.min(cx, window.innerWidth - cw - MARGIN2));
      let cy = rect.top - ch - CHIP_GAP - 2;
      if (cy < MARGIN2) cy = rect.bottom + CHIP_GAP + 2;
      cy = Math.max(MARGIN2, Math.min(cy, window.innerHeight - ch - MARGIN2));
      this.chip.style.left = `${Math.round(cx)}px`;
      this.chip.style.top = `${Math.round(cy)}px`;
    }
  };

  // src/shared/models.ts
  var DEFAULT_MODEL = "claude-haiku-4-5";

  // src/shared/settings.ts
  var KEYS = ["model", "enabled"];
  async function getSettings() {
    const raw = await chrome.storage.local.get(KEYS);
    return {
      model: typeof raw.model === "string" && raw.model ? raw.model : DEFAULT_MODEL,
      enabled: raw.enabled !== false
    };
  }
  function onSettingsChanged(cb) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const patch = {};
      for (const k of KEYS) {
        if (k in changes) patch[k] = changes[k].newValue;
      }
      if (Object.keys(patch).length > 0) cb(patch);
    });
  }

  // src/content/index.ts
  var enabled = true;
  var consentAck = false;
  var popup = null;
  var session = null;
  var spotlight = null;
  function closePopup() {
    session?.abort();
    session = null;
    popup?.destroy();
    popup = null;
  }
  function errorText(code, message) {
    switch (code) {
      case "no_key":
        return {
          text: "OnboardAI needs an Anthropic API key to answer. Add one in settings \u2014 it stays on this device.",
          setup: true
        };
      case "auth":
        return { text: `The API rejected your key: ${message}`, setup: true };
      case "network":
        return { text: message, setup: false };
      case "api":
        return { text: `Something went wrong: ${message}`, setup: false };
    }
  }
  function runSend(text, hidden) {
    if (!popup || !session || session.busy) return;
    const p = popup;
    if (!hidden) p.addUser(text);
    p.startAssistant();
    session.send(text, {
      onDelta: (t) => {
        if (popup === p) p.appendDelta(t);
      },
      onDone: () => {
        if (popup === p) p.finishAssistant();
      },
      onError: (code, message) => {
        if (popup !== p) return;
        p.finishAssistant();
        const { text: msg, setup } = errorText(code, message);
        p.showError(msg, setup);
      }
    });
  }
  function openFor(t) {
    closePopup();
    const { el: resolved, label: feature } = resolveTarget(t.target);
    const context = extractContext(resolved, feature);
    session = new ChatSession(context);
    popup = new Popup(t.x, t.y, feature, {
      onSend: (text) => runSend(text, false),
      onClose: closePopup,
      onOpenOptions: () => void chrome.runtime.sendMessage({ type: "open-options" })
    });
    const p = popup;
    const seed = `Explain the "${feature}" element on this page \u2014 what it is, what it does, and why it matters.`;
    if (consentAck) {
      runSend(seed, true);
    } else {
      p.showConsent(() => {
        if (popup !== p) return;
        consentAck = true;
        void chrome.storage.local.set({ consentAck: true });
        runSend(seed, true);
      });
    }
  }
  var trigger = initTrigger({
    isEnabled: () => enabled,
    isOurNode: (path) => popup ? popup.containsPath(path) : false,
    onTrigger: openFor,
    // Spotlight lifetime == modifier held (blur/⌘-Tab auto-emit false).
    onModifier: (held) => {
      if (held) {
        spotlight ??= new Spotlight();
        spotlight.show();
      } else {
        spotlight?.hide();
      }
    }
  });
  window.addEventListener(
    "mousedown",
    (e) => {
      if (!popup) return;
      if (e.metaKey || e.ctrlKey) return;
      if (popup.containsPath(e.composedPath())) return;
      closePopup();
    },
    { capture: true }
  );
  window.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "Escape" && popup) closePopup();
    },
    { capture: true }
  );
  void getSettings().then((s) => {
    enabled = s.enabled;
  });
  void chrome.storage.local.get("consentAck").then((r) => {
    consentAck = r.consentAck === true;
  });
  onSettingsChanged((patch) => {
    if (patch.enabled !== void 0) {
      enabled = patch.enabled;
      if (!enabled) {
        trigger.reset();
        closePopup();
        spotlight?.destroy();
        spotlight = null;
      }
    }
  });
})();
