// src/shared/messages.ts
var CHAT_PORT_NAME = "onboardai-chat";

// src/shared/models.ts
var DEFAULT_MODEL = "claude-haiku-4-5";
var MAX_TOKENS = 1024;

// src/shared/settings.ts
var KEYS = ["model", "enabled"];
async function getSettings() {
  const raw = await chrome.storage.local.get(KEYS);
  return {
    model: typeof raw.model === "string" && raw.model ? raw.model : DEFAULT_MODEL,
    enabled: raw.enabled !== false
  };
}

// src/background.ts
var API_URL = "https://onboardai-shoofly.netlify.app/.netlify/functions/anthropic";
var SYSTEM_PROMPT = `You are OnboardAI, Shoofly's on-page guide \u2014 a browser extension that acts as an instant onboarding guide for any website. The user held \u2318/Ctrl and clicked an element on the page they are viewing to ask what it is \u2014 the clicked element and page details are given in PAGE CONTEXT below.

RULES:
- Start by explaining THAT element: what it does, who it's for, and why it matters \u2014 plain language, no jargon.
- Ground your answer in the PAGE CONTEXT. You may combine it with general knowledge of well-known sites (e.g. what "Fork" means on GitHub), but NEVER invent site-specific features. If you aren't sure what something does, say so plainly.
- You are an explainer, NOT an operator. You cannot click, submit, navigate, or change anything \u2014 and you must never claim to. If asked to do something, explain HOW the user would do it instead.
- Answer follow-ups (including "what would happen if\u2026") the same way: short and grounded.
- Keep every reply SHORT \u2014 it renders in a small popup: 2-4 sentences or up to 4 tight bullets. Light markdown only (bold, bullets). No headings, no code blocks unless the user asks about code.`;
function post(port, msg) {
  try {
    port.postMessage(msg);
    return true;
  } catch {
    return false;
  }
}
async function handleChat(port, req, signal) {
  const settings = await getSettings();
  let res;
  try {
    res = await fetch(API_URL, {
      method: "POST",
      signal,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        model: settings.model,
        max_tokens: MAX_TOKENS,
        stream: true,
        system: `${SYSTEM_PROMPT}

PAGE CONTEXT:
${req.context}`,
        messages: req.messages.slice(-12)
      })
    });
  } catch (err) {
    if (signal.aborted) return;
    post(port, { type: "error", code: "network", message: `Could not reach the Anthropic API (${err.message}). Check your connection.` });
    return;
  }
  if (!res.ok) {
    let detail = "";
    try {
      const body = await res.json();
      detail = body?.error?.message ?? "";
    } catch {
    }
    if (res.status === 401 || res.status === 403) {
      post(port, { type: "error", code: "auth", message: detail || "Your API key was rejected. Check it in OnboardAI settings." });
    } else {
      post(port, { type: "error", code: "api", message: detail || `Anthropic API error (HTTP ${res.status}).` });
    }
    return;
  }
  if (!res.body) {
    post(port, { type: "error", code: "api", message: "Empty response from the Anthropic API." });
    return;
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf("\n")) !== -1) {
        const line = buf.slice(0, nl).replace(/\r$/, "");
        buf = buf.slice(nl + 1);
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        let ev;
        try {
          ev = JSON.parse(data);
        } catch {
          continue;
        }
        if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta" && ev.delta.text) {
          if (!post(port, { type: "delta", text: ev.delta.text })) return;
        } else if (ev.type === "error") {
          post(port, { type: "error", code: "api", message: ev.error?.message ?? "Stream error." });
          return;
        }
      }
    }
  } catch (err) {
    if (!signal.aborted) {
      post(port, { type: "error", code: "network", message: `Stream interrupted (${err.message}).` });
    }
    return;
  }
  post(port, { type: "done" });
}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== CHAT_PORT_NAME) return;
  const controller = new AbortController();
  port.onDisconnect.addListener(() => controller.abort());
  port.onMessage.addListener((msg) => {
    if (msg?.type === "chat") {
      void handleChat(port, msg, controller.signal);
    }
  });
});
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "open-options") {
    void chrome.runtime.openOptionsPage();
  }
});
