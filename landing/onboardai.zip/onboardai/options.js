"use strict";
(() => {
  // src/shared/models.ts
  var MODEL_OPTIONS = [
    { id: "claude-haiku-4-5", label: "Claude Haiku 4.5 \u2014 fast (recommended)" },
    { id: "claude-sonnet-4-5", label: "Claude Sonnet 4.5 \u2014 smarter, slower" }
  ];
  var DEFAULT_MODEL = "claude-haiku-4-5";

  // src/shared/settings.ts
  var KEYS = ["model", "enabled"];
  async function getSettings() {
    const raw = await chrome.storage.local.get(KEYS);
    return {
      model: typeof raw.model === "string" && raw.model ? raw.model : DEFAULT_MODEL,
      enabled: raw.enabled !== false
    };
  }
  async function saveSettings(patch) {
    await chrome.storage.local.set(patch);
  }

  // src/options/options.ts
  var $ = (id) => document.getElementById(id);
  var modelEl = $("model");
  var enabledEl = $("enabled");
  var saveEl = $("save");
  var statusEl = $("status");
  for (const m of MODEL_OPTIONS) {
    const opt = document.createElement("option");
    opt.value = m.id;
    opt.textContent = m.label;
    modelEl.appendChild(opt);
  }
  var statusTimer;
  function setStatus(text, isError = false) {
    statusEl.textContent = text;
    statusEl.classList.toggle("err", isError);
    clearTimeout(statusTimer);
    if (text) statusTimer = setTimeout(() => statusEl.textContent = "", 2500);
  }
  async function load() {
    const s = await getSettings();
    modelEl.value = s.model || DEFAULT_MODEL;
    enabledEl.checked = s.enabled;
  }
  async function save() {
    await saveSettings({ model: modelEl.value, enabled: enabledEl.checked });
    setStatus("Saved \u2713");
  }
  saveEl.addEventListener("click", () => void save());
  enabledEl.addEventListener("change", () => {
    void saveSettings({ enabled: enabledEl.checked });
    setStatus(enabledEl.checked ? "Enabled" : "Disabled \u2014 native \u2318-click restored");
  });
  void load();
  var uninstallEl = $("uninstall");
  uninstallEl.addEventListener("click", () => {
    if (confirm("Remove OnboardAI from Chrome?\n\nYou can always reinstall it later from the Shoofly website.")) {
      chrome.management.uninstallSelf({ showConfirmDialog: false });
    }
  });
})();
